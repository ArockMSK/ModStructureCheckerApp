﻿using System;
using System.Windows.Forms;

namespace ModStructureCheckerApp
{
    public partial class ErrorStatusForm : Form
    {
        private TextBox txtErrorLog = null!;
        private Button btnClose = null!;

        public ErrorStatusForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            txtErrorLog = new TextBox
            {
                Location = new System.Drawing.Point(12, 12),
                Multiline = true,
                Name = "txtErrorLog",
                ScrollBars = ScrollBars.Vertical,
                Size = new System.Drawing.Size(360, 200),
                TabIndex = 0,
                ReadOnly = true
            };

            btnClose = new Button
            {
                Location = new System.Drawing.Point(150, 218),
                Name = "btnClose",
                Size = new System.Drawing.Size(75, 23),
                TabIndex = 1,
                Text = "Закрыть",
                UseVisualStyleBackColor = true
            };
            btnClose.Click += BtnClose_Click;

            ClientSize = new System.Drawing.Size(384, 250);
            Controls.Add(btnClose);
            Controls.Add(txtErrorLog);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "ErrorStatusForm";
            Text = "Статус ошибок";
            StartPosition = FormStartPosition.CenterParent;
        }

        private void BtnClose_Click(object? sender, EventArgs e)
        {
            this.Close();
        }

        public void AddError(string errorMessage)
        {
            if (txtErrorLog.Text.Length > 0)
                txtErrorLog.Text += "\r\n";
            txtErrorLog.Text += $"[{DateTime.Now:HH:mm:ss}] {errorMessage} ❌";
        }

        public bool IsErrorLogEmpty()
        {
            return string.IsNullOrEmpty(txtErrorLog.Text);
        }
    }
}