﻿using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ModStructureCheckerApp
{
    public partial class Form1 : Form
    {
        private string selectedFolder = "";
        private string saveFolder = "";
        private ErrorStatusForm? errorForm = null; // Nullable reference type

        public Form1()
        {
            InitializeComponent();
            txtStatus.Font = new System.Drawing.Font("Segoe UI Emoji", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
        }

        private void PrintTree(string path, string indent, bool isLast, StreamWriter writer)
        {
            string dirName = Path.GetFileName(path);
            writer.WriteLine(indent + (isLast ? "└─ " : "├─ ") + dirName);
            string newIndent = indent + (isLast ? "   " : "│  ");
            try
            {
                string[] subDirs = Directory.GetDirectories(path);
                for (int i = 0; i < subDirs.Length; i++)
                {
                    PrintTree(subDirs[i], newIndent, i == subDirs.Length - 1, writer);
                }
                string[] files = Directory.GetFiles(path);
                for (int i = 0; i < files.Length; i++)
                {
                    string fileName = Path.GetFileName(files[i]);
                    writer.WriteLine(newIndent + (i == files.Length - 1 ? "└─ " : "├─ ") + fileName);
                }
            }
            catch (Exception ex)
            {
                writer.WriteLine(indent + "[ERROR] " + ex.Message);
                if (errorForm != null && !errorForm.IsDisposed)
                    errorForm.AddError($"Ошибка при обработке директории {path}: {ex.Message}");
            }
        }

        private void btnSelectFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Выберите папку с модами";
                folderDialog.ShowNewFolderButton = false;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    selectedFolder = folderDialog.SelectedPath;
                    txtStatus.Text = $"Выбрана папка с модами: {selectedFolder} 📁\r\n";
                    saveFolder = selectedFolder;
                    txtSavePath.Text = saveFolder;
                }
            }
        }

        private void btnSaveFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Выберите папку для сохранения результата";
                folderDialog.ShowNewFolderButton = true;
                folderDialog.SelectedPath = saveFolder;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    saveFolder = folderDialog.SelectedPath;
                    txtSavePath.Text = saveFolder;
                    txtStatus.Text += $"Папка сохранения изменена на: {saveFolder} 🗂️\r\n";
                }
            }
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectedFolder))
            {
                MessageBox.Show("Пожалуйста, выберите папку с модами!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(saveFolder))
            {
                saveFolder = selectedFolder;
                txtSavePath.Text = saveFolder;
            }

            string outputFile = Path.Combine(saveFolder, "ModFullData.txt");
            string[] textExtensions = { ".xml", ".cs", ".txt" };
            string[] imageExtensions = { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

            // Открытие окна ошибок
            errorForm = new ErrorStatusForm();
            errorForm.Show(this);

            try
            {
                txtStatus.Text = "Сборка началась... ⏳\r\n";
                using (StreamWriter writer = new StreamWriter(outputFile, false, Encoding.UTF8))
                {
                    writer.WriteLine($"Полная сборка данных модов начата: {DateTime.Now}");
                    writer.WriteLine();

                    string[] modFolders = Directory.GetDirectories(selectedFolder);
                    foreach (var modPath in modFolders)
                    {
                        string modName = Path.GetFileName(modPath);
                        writer.WriteLine($"Мод: {modName}");
                        writer.WriteLine(new string('-', 50));

                        // Структура директорий
                        writer.WriteLine("Directory Structure:");
                        PrintTree(modPath, "", true, writer);
                        writer.WriteLine();

                        // Текстовые файлы
                        writer.WriteLine("Text Files:");
                        foreach (var ext in textExtensions)
                        {
                            string[] files = Directory.GetFiles(modPath, "*" + ext, SearchOption.AllDirectories);
                            foreach (var file in files)
                            {
                                writer.WriteLine($"Файл: {file}");
                                writer.WriteLine($"Тип: {ext.TrimStart('.')}");
                                writer.WriteLine("Содержимое:");
                                try
                                {
                                    string content = File.ReadAllText(file, Encoding.UTF8);
                                    writer.WriteLine(content);
                                }
                                catch (Exception ex)
                                {
                                    writer.WriteLine($"[ОШИБКА] Не удалось прочитать файл: {ex.Message}");
                                    if (errorForm != null && !errorForm.IsDisposed)
                                        errorForm.AddError($"Ошибка при чтении файла {file}: {ex.Message}");
                                }
                                writer.WriteLine(new string('-', 50));
                            }
                        }
                        writer.WriteLine();

                        // Изображения
                        writer.WriteLine("Image Files:");
                        foreach (var ext in imageExtensions)
                        {
                            string[] files = Directory.GetFiles(modPath, "*" + ext, SearchOption.AllDirectories);
                            foreach (var file in files)
                            {
                                writer.WriteLine($"Файл: {file}");
                                writer.WriteLine($"Тип: {ext.TrimStart('.')}");
                                try
                                {
                                    using (Bitmap bitmap = new Bitmap(file))
                                    {
                                        int width = bitmap.Width;
                                        int height = bitmap.Height;
                                        long fileSize = new FileInfo(file).Length;
                                        writer.WriteLine($"Dimensions: {width}x{height} pixels");
                                        writer.WriteLine($"File Size: {fileSize} bytes");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    writer.WriteLine($"[ОШИБКА] Не удается прочитать изображение: {ex.Message}");
                                    if (errorForm != null && !errorForm.IsDisposed)
                                        errorForm.AddError($"Ошибка при обработке изображения {file}: {ex.Message}");
                                }
                                writer.WriteLine(new string('-', 50));
                            }
                        }
                        writer.WriteLine();
                    }
                    writer.WriteLine("Сборка завершена. ✅");
                }
                txtStatus.Text += $"Сборка завершена. Файл сохранен: {outputFile} 📄\r\n";
            }
            catch (Exception ex)
            {
                txtStatus.Text += $"Ошибка: {ex.Message} ❌\r\n";
                if (errorForm != null && !errorForm.IsDisposed)
                    errorForm.AddError($"Общая ошибка сборки: {ex.Message}");
            }
            finally
            {
                if (errorForm != null && !errorForm.IsDisposed && errorForm.IsErrorLogEmpty())
                {
                    errorForm.Close(); // Закрываем, если ошибок нет
                }
            }
        }

        private void LogError(string errorMessage)
        {
            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "error.log");
                File.AppendAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {errorMessage}\r\n");
            }
            catch (Exception)
            {
                // Игнорируем ошибки записи лога, чтобы не прерывать выполнение
            }
        }
    }
}