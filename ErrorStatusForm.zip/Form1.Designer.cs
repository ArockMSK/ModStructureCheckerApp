﻿namespace ModStructureCheckerApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSelectFolder = new Button();
            btnRun = new Button();
            txtStatus = new TextBox();
            label1 = new Label();
            btnSaveFolder = new Button();
            txtSavePath = new TextBox();
            label2 = new Label();
            labelAuthor = new Label();
            SuspendLayout();
            // 
            // btnSelectFolder
            // 
            btnSelectFolder.Location = new Point(12, 12);
            btnSelectFolder.Name = "btnSelectFolder";
            btnSelectFolder.Size = new Size(150, 30);
            btnSelectFolder.TabIndex = 0;
            btnSelectFolder.Text = "Выбрать папку 📁";
            btnSelectFolder.UseVisualStyleBackColor = true;
            btnSelectFolder.Click += btnSelectFolder_Click;
            // 
            // btnRun
            // 
            btnRun.Location = new Point(168, 12);
            btnRun.Name = "btnRun";
            btnRun.Size = new Size(150, 30);
            btnRun.TabIndex = 1;
            btnRun.Text = "Запустить сборку ▶️";
            btnRun.UseVisualStyleBackColor = true;
            btnRun.Click += btnRun_Click;
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(13, 82);
            txtStatus.Multiline = true;
            txtStatus.Name = "txtStatus";
            txtStatus.ScrollBars = ScrollBars.Vertical;
            txtStatus.Size = new Size(406, 138);
            txtStatus.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 55);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 3;
            label1.Text = "Статус: 📋";
            // 
            // btnSaveFolder
            // 
            btnSaveFolder.Location = new Point(12, 255);
            btnSaveFolder.Name = "btnSaveFolder";
            btnSaveFolder.Size = new Size(229, 30);
            btnSaveFolder.TabIndex = 4;
            btnSaveFolder.Text = "Выбрать папку сохранения 📂";
            btnSaveFolder.UseVisualStyleBackColor = true;
            btnSaveFolder.Click += btnSaveFolder_Click;
            // 
            // txtSavePath
            // 
            txtSavePath.Location = new Point(12, 291);
            txtSavePath.Name = "txtSavePath";
            txtSavePath.Size = new Size(406, 23);
            txtSavePath.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 237);
            label2.Name = "label2";
            label2.Size = new Size(149, 15);
            label2.TabIndex = 6;
            label2.Text = "Папка для сохранения: 🗂️";
            // 
            // labelAuthor
            // 
            labelAuthor.AutoSize = true;
            labelAuthor.Location = new Point(12, 320);
            labelAuthor.Name = "labelAuthor";
            labelAuthor.Size = new Size(200, 15); // Примерная ширина
            labelAuthor.TabIndex = 7;
            labelAuthor.Text = "v1.0.0 by Arock (Built with Grok from xAI)";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(430, 350); // Увеличено для labelAuthor
            Controls.Add(labelAuthor);
            Controls.Add(label2);
            Controls.Add(txtSavePath);
            Controls.Add(btnSaveFolder);
            Controls.Add(label1);
            Controls.Add(txtStatus);
            Controls.Add(btnRun);
            Controls.Add(btnSelectFolder);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            Text = "ModStructureCheckerApp";
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSelectFolder;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSaveFolder;
        private System.Windows.Forms.TextBox txtSavePath;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelAuthor;
    }
}